class_name Data

# Умножитель мощности. Если машина слишком медленная или слишком быстрая, меняй это число.
const POWER_K := 55.0
# Части имён узлов модели, которые прячем (родные колёса модели, у нас свои, с кастомными дисками).
const HIDE := ["wheel", "tire", "tyre"]

# model: файл в res://models/ (если файла нет, будет простая заглушка-кузов)
# scale/yaw/dy: подгонка модели (масштаб, поворот вокруг Y в радианах, высота)
# paint: кусок названия материала кузова в модели (смотри в Godot, вкладка Import -> Materials)
const CARS := [
    {"n": "Mitsubishi Lancer Evo VII", "model": "lancer_evo7.glb", "hp": 280, "kg": 1400, "drive": "awd", "color": Color("#e5e7eb"), "length": 4.35, "width": 1.76, "scale": 1.0, "yaw": 0.0, "dy": 0.0, "paint": "body"},
    {"n": "Subaru Impreza WRX STI 2004", "model": "impreza_sti.glb", "hp": 280, "kg": 1500, "drive": "awd", "color": Color("#1d4ed8"), "length": 4.4, "width": 1.74, "scale": 1.0, "yaw": 0.0, "dy": 0.0, "paint": "body"},
    {"n": "Toyota Mark II JZX100", "model": "mark2.glb", "hp": 280, "kg": 1500, "drive": "rwd", "color": Color("#111827"), "length": 4.7, "width": 1.75, "scale": 1.0, "yaw": 0.0, "dy": 0.0, "paint": "body"},
    {"n": "Nissan 350Z", "model": "350z.glb", "hp": 300, "kg": 1450, "drive": "rwd", "color": Color("#f59e0b"), "length": 4.3, "width": 1.82, "scale": 1.0, "yaw": 0.0, "dy": 0.0, "paint": "body"},
    {"n": "Toyota AE86 Trueno", "model": "ae86.glb", "hp": 130, "kg": 950, "drive": "rwd", "color": Color("#f8fafc"), "length": 4.2, "width": 1.63, "scale": 1.0, "yaw": 0.0, "dy": 0.0, "paint": "body"},
    {"n": "Mazda RX-7 FD3S", "model": "rx7.glb", "hp": 255, "kg": 1280, "drive": "rwd", "color": Color("#dc2626"), "length": 4.3, "width": 1.75, "scale": 1.0, "yaw": 0.0, "dy": 0.0, "paint": "body"},
    {"n": "Nissan Skyline GT-R R34", "model": "r34.glb", "hp": 280, "kg": 1560, "drive": "awd", "color": Color("#6366f1"), "length": 4.6, "width": 1.79, "scale": 1.0, "yaw": 0.0, "dy": 0.0, "paint": "body"},
    {"n": "Toyota Supra A80", "model": "supra.glb", "hp": 280, "kg": 1500, "drive": "rwd", "color": Color("#f97316"), "length": 4.5, "width": 1.81, "scale": 1.0, "yaw": 0.0, "dy": 0.0, "paint": "body"},
]

# Свапы мотора: hp (общая мощность), kg (добавка к весу)
const ENGINES := [
    {"n": "Стоковый", "hp": 0, "kg": 0},
    {"n": "RB26DETT 2.6 bi-turbo (340 л.с.)", "hp": 340, "kg": 60},
    {"n": "2JZ-GTE 3.0 turbo (400 л.с.)", "hp": 400, "kg": 70},
    {"n": "4G63T 2.0 turbo (320 л.с.)", "hp": 320, "kg": -60},
    {"n": "SR20DET 2.0 turbo (270 л.с.)", "hp": 270, "kg": -80},
    {"n": "13B-REW ротор (300 л.с.)", "hp": 300, "kg": -90},
    {"n": "LS3 V8 6.2 (430 л.с.)", "hp": 430, "kg": 120},
]
