class_name Car
extends VehicleBody3D

var cfg: Dictionary
var tune: Dictionary
var mode := "drift"
var is_local := true
var steer_in := 0.0   # -1 влево, +1 вправо
var gas := 0.0
var brk := 0.0
var hand := false
var hp := 280.0
var grip_f := 4.5
var grip_r := 3.0
var wheels: Array[VehicleWheel3D] = []
var paint_mats: Array[StandardMaterial3D] = []
var rim_mats: Array[StandardMaterial3D] = []

func setup(idx: int, t: Dictionary, m: String) -> void:
    cfg = Data.CARS[idx]
    tune = t
    mode = m
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(cfg.width, 0.8, cfg.length)
    cs.shape = bs
    cs.position.y = 0.75
    add_child(cs)
    _load_model()
    _add_kit()
    _add_wheels()
    apply_physics()
    apply_paint()
    if not is_local:
        freeze = true
        collision_layer = 0
        collision_mask = 0

func _mat(c: Color, rough := 0.5, metal := 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    m.metallic = metal
    return m

func _box(size: Vector3, pos: Vector3, mat: StandardMaterial3D) -> void:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.position = pos
    mi.material_override = mat
    add_child(mi)

func _load_model() -> void:
    var path: String = "res://models/" + cfg.model
    if ResourceLoader.exists(path):
        var inst := (load(path) as PackedScene).instantiate() as Node3D
        inst.scale = Vector3.ONE * float(cfg.scale)
        inst.rotation.y = float(cfg.yaw)
        inst.position.y = float(cfg.dy)
        add_child(inst)
        _walk(inst)
    else:
        var body := _mat(Color.WHITE, 0.3, 0.4)
        paint_mats.append(body)
        _box(Vector3(cfg.width, 0.6, cfg.length), Vector3(0, 0.65, 0), body)
        _box(Vector3(cfg.width * 0.84, 0.5, cfg.length * 0.45), Vector3(0, 1.15, cfg.length * 0.05), _mat(Color("#1f2937"), 0.1))

func _walk(n: Node) -> void:
    if n is Node3D:
        var nm := String(n.name).to_lower()
        for k in Data.HIDE:
            if nm.contains(k):
                (n as Node3D).visible = false
                return
    if n is MeshInstance3D:
        var mi := n as MeshInstance3D
        for i in mi.get_surface_override_material_count():
            var m := mi.get_active_material(i)
            if m is StandardMaterial3D and m.resource_name.to_lower().contains(String(cfg.paint)):
                var d := m.duplicate() as StandardMaterial3D
                mi.set_surface_override_material(i, d)
                paint_mats.append(d)
    for c in n.get_children():
        _walk(c)

# Перед машины = -Z, зад = +Z
func _add_kit() -> void:
    var L: float = cfg.length
    var W: float = cfg.width
    var dark := _mat(Color("#101010"), 0.6)
    if tune.kit > 0:
        _box(Vector3(W, 0.08, 0.4), Vector3(0, 0.3, -L / 2.0), dark)
        _box(Vector3(W, 0.08, 0.3), Vector3(0, 0.3, L / 2.0), dark)
        for s in [-1, 1]:
            _box(Vector3(0.08, 0.14, L * 0.5), Vector3(s * W / 2.0, 0.32, 0), dark)
    if tune.kit == 2:
        var pm := _mat(Color.WHITE, 0.3, 0.4)
        paint_mats.append(pm)
        for s in [-1, 1]:
            for z in [-1, 1]:
                _box(Vector3(0.25, 0.3, 1.3), Vector3(s * (W / 2.0 + 0.05), 0.65, z * L * 0.3), pm)
    if tune.wing == 1:
        var pm2 := _mat(Color.WHITE, 0.3, 0.4)
        paint_mats.append(pm2)
        _box(Vector3(W * 0.8, 0.06, 0.4), Vector3(0, 1.2, L / 2.0 - 0.2), pm2)
    elif tune.wing == 2:
        _box(Vector3(W * 0.95, 0.06, 0.55), Vector3(0, 1.6, L / 2.0 - 0.1), dark)
        for s in [-1, 1]:
            _box(Vector3(0.08, 0.4, 0.1), Vector3(s * W * 0.3, 1.4, L / 2.0 - 0.1), dark)

func _add_wheels() -> void:
    var L: float = cfg.length
    var W: float = cfg.width
    var r: float = 0.34 * float(tune.rim_size)
    var tire_m := _mat(Color("#151515"), 0.9)
    for fz in [-1, 1]:
        for sx in [-1, 1]:
            var w := VehicleWheel3D.new()
            var extra := 0.1 if tune.kit == 2 else 0.0
            w.position = Vector3(sx * (W / 2.0 - 0.12 + extra), 0.55, fz * L * 0.32)
            w.use_as_steering = fz < 0
            w.use_as_traction = (cfg.drive == "awd") or fz > 0
            w.wheel_radius = r
            var tire := MeshInstance3D.new()
            var tm := CylinderMesh.new()
            tm.top_radius = r
            tm.bottom_radius = r
            tm.height = 0.24
            tire.mesh = tm
            tire.rotation_degrees.z = 90
            tire.material_override = tire_m
            w.add_child(tire)
            var rim := MeshInstance3D.new()
            var rm := CylinderMesh.new()
            rm.top_radius = r * 0.66
            rm.bottom_radius = r * 0.66
            rm.height = 0.26
            rim.mesh = rm
            rim.rotation_degrees.z = 90
            var rmat := _mat(Color.WHITE, 0.25, 0.8)
            rim.material_override = rmat
            rim_mats.append(rmat)
            w.add_child(rim)
            add_child(w)
            wheels.append(w)

func apply_paint() -> void:
    for m in paint_mats:
        m.albedo_color = tune.color
    for m in rim_mats:
        m.albedo_color = tune.rim

func apply_physics() -> void:
    var e: Dictionary = Data.ENGINES[tune.engine]
    hp = float(e.hp) if tune.engine > 0 else float(cfg.hp)
    mass = float(cfg.kg) + (float(e.kg) if tune.engine > 0 else 0.0)
    center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
    var st: float = tune.stiff
    var hg: float = tune.height
    var bi: float = tune.bias
    center_of_mass = Vector3(0, 0.3 + hg * 0.2, 0)
    var rally := mode == "rally"
    var gf := 4.6 if rally else 5.0
    var gr := 4.6 if rally else 3.2
    grip_f = gf * (1.3 - bi * 0.6) * (0.9 + 0.2 * st)
    grip_r = gr * (0.7 + bi * 0.6) * (0.9 + 0.2 * st)
    for i in wheels.size():
        var w := wheels[i]
        w.suspension_stiffness = 25.0 + st * 45.0
        w.damping_compression = 0.6 + st * 0.4
        w.damping_relaxation = 0.8 + st * 0.4
        w.suspension_travel = 0.2 + hg * 0.35
        w.wheel_rest_length = 0.12 + hg * 0.3
        w.wheel_roll_influence = 0.25 - st * 0.15
        w.wheel_friction_slip = grip_f if i < 2 else grip_r

func slip_angle() -> float:
    var lv := global_transform.basis.inverse() * linear_velocity
    return atan2(absf(lv.x), absf(lv.z) + 0.1)

func speed_kmh() -> float:
    return linear_velocity.length() * 3.6

func _physics_process(dt: float) -> void:
    if not is_local or freeze:
        return
    var spd := linear_velocity.length()
    var vf := linear_velocity.dot(-global_transform.basis.z)
    var n := 4.0 if cfg.drive == "awd" else 2.0
    var taper := clampf(1.0 - vf / (55.0 + hp / 10.0), 0.0, 1.0)
    var total := gas * hp * Data.POWER_K * taper
    var rev := brk > 0.0 and vf < 1.0
    if rev:
        total = -hp * 12.0
    engine_force = total / n
    var b := 0.0 if rev else brk * mass * 0.04
    var maxs := lerpf(0.6 if mode == "drift" else 0.5, 0.2, clampf(spd / 40.0, 0.0, 1.0))
    steering = move_toward(steering, -steer_in * maxs, dt * 3.5)
    for i in wheels.size():
        wheels[i].brake = b
    if hand:
        for i in [2, 3]:
            wheels[i].wheel_friction_slip = 0.9
            wheels[i].brake = mass * 0.03
    else:
        var cut := 0.35 * gas if (cfg.drive == "rwd" and mode == "drift") else 0.0
        for i in [2, 3]:
            wheels[i].wheel_friction_slip = grip_r * (1.0 - cut)
