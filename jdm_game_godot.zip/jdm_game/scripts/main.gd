extends Node3D

const PORT := 9999
var mode := "drift"
var car_idx := 0
var tune := {"engine": 0, "stiff": 0.5, "height": 0.5, "bias": 0.5, "color": Color("#e5e7eb"), "kit": 0, "wing": 0, "rim": Color("#d1d5db"), "rim_size": 1.0}
var car: Car
var cam: Camera3D
var cam_dir := Vector3(0, 0, -1)
var in_menu := true
var world: Node3D
var beacon: MeshInstance3D
var cps: Array[Vector3] = []
var cp := 1
var t_lap := 0.0
var lap_last := 0.0
var best := 0.0
var cur := 0.0
var total := 0.0
var idle := 0.0
var orbit := 0.0
var frame := 0
var touches := {}
var rects := {}
var pad_nodes := {}
var remotes := {}
var play: Control
var hud: Label
var menu: PanelContainer
var ip_label: Label
var body_picker: ColorPickerButton
var rim_slider: HSlider

func _ready() -> void:
    _setup_env()
    cam = Camera3D.new()
    cam.fov = 70
    add_child(cam)
    _build_world()
    _spawn_car()
    _build_ui()
    multiplayer.peer_disconnected.connect(_on_peer_gone)
    get_viewport().size_changed.connect(_layout)
    _layout()

# ---------- мир ----------
func _setup_env() -> void:
    var env := Environment.new()
    var sky := Sky.new()
    sky.sky_material = ProceduralSkyMaterial.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.glow_enabled = true
    env.fog_enabled = true
    env.fog_density = 0.002
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50, -30, 0)
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 90.0
    add_child(sun)

func _mat(c: Color, r := 0.9) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = r
    return m

func _build_world() -> void:
    if world:
        world.queue_free()
    world = Node3D.new()
    add_child(world)
    cps.clear()
    var rally := mode == "rally"
    var g := StaticBody3D.new()
    world.add_child(g)
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = Vector3(1200, 2, 1200)
    cs.shape = bs
    cs.position.y = -1
    g.add_child(cs)
    var pm := PhysicsMaterial.new()
    pm.friction = 1.0
    g.physics_material_override = pm
    var mi := MeshInstance3D.new()
    var pl := PlaneMesh.new()
    pl.size = Vector2(1200, 1200)
    mi.mesh = pl
    mi.material_override = _mat(Color("#5b8c3a") if rally else Color("#3f4650"))
    g.add_child(mi)
    if rally:
        _build_rally()
    else:
        _build_drift()

func _cone(p: Vector3) -> void:
    var b := RigidBody3D.new()
    b.mass = 4.0
    b.position = p + Vector3(0, 0.5, 0)
    var cs := CollisionShape3D.new()
    var sh := CylinderShape3D.new()
    sh.radius = 0.3
    sh.height = 1.0
    cs.shape = sh
    b.add_child(cs)
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.03
    cm.bottom_radius = 0.3
    cm.height = 1.0
    mi.mesh = cm
    mi.material_override = _mat(Color("#fb6a1f"))
    b.add_child(mi)
    world.add_child(b)

func _build_drift() -> void:
    for i in 32:
        var t := float(i) / 32.0 * TAU
        _cone(Vector3(cos(t) * 75.0, 0, sin(t) * 75.0))
    for i in 6:
        _cone(Vector3(-10, 0, 25 + i * 12))
        _cone(Vector3(10, 0, 25 + i * 12))
    for i in 16:
        var t2 := float(i) / 16.0 * TAU
        _cone(Vector3(cos(t2) * 30.0, 0, sin(t2) * 30.0 - 35.0))

func _build_rally() -> void:
    var n := 10
    var road_pts: Array[Vector3] = []
    for i in n:
        var t := float(i) / n * TAU
        var r := 110.0 + 30.0 * sin(3.0 * t)
        cps.append(Vector3(cos(t) * r, 0, sin(t) * r))
    var road_m := _mat(Color("#a16207"))
    for i in n:
        var a := cps[i]
        var b := cps[(i + 1) % n]
        var d := b - a
        var seg := MeshInstance3D.new()
        var bm := BoxMesh.new()
        bm.size = Vector3(14, 0.06, d.length())
        seg.mesh = bm
        seg.material_override = road_m
        seg.position = (a + b) / 2.0 + Vector3(0, 0.03, 0)
        seg.rotation.y = atan2(d.x, d.z)
        world.add_child(seg)
        var j := MeshInstance3D.new()
        var cm := CylinderMesh.new()
        cm.top_radius = 7.0
        cm.bottom_radius = 7.0
        cm.height = 0.06
        j.mesh = cm
        j.material_override = road_m
        j.position = a + Vector3(0, 0.03, 0)
        world.add_child(j)
        for k in 6:
            road_pts.append(a + d * float(k) / 6.0)
    var rng := RandomNumberGenerator.new()
    rng.seed = 7
    var leaf_m := _mat(Color("#15803d"))
    var trunk_m := _mat(Color("#78350f"))
    for i in 170:
        var p := Vector3(rng.randf_range(-280, 280), 0, rng.randf_range(-280, 280))
        var ok := true
        for q in road_pts:
            if p.distance_to(q) < 16.0:
                ok = false
                break
        if not ok:
            continue
        var tb := StaticBody3D.new()
        tb.position = p
        var tc := CollisionShape3D.new()
        var ts := CylinderShape3D.new()
        ts.radius = 0.5
        ts.height = 4.0
        tc.shape = ts
        tc.position.y = 2.0
        tb.add_child(tc)
        var tr := MeshInstance3D.new()
        var tcm := CylinderMesh.new()
        tcm.top_radius = 0.4
        tcm.bottom_radius = 0.5
        tcm.height = 3.0
        tr.mesh = tcm
        tr.material_override = trunk_m
        tr.position.y = 1.5
        tb.add_child(tr)
        var lf := MeshInstance3D.new()
        var lcm := CylinderMesh.new()
        lcm.top_radius = 0.0
        lcm.bottom_radius = 2.4
        lcm.height = 6.0
        lf.mesh = lcm
        lf.material_override = leaf_m
        lf.position.y = 5.5
        tb.add_child(lf)
        world.add_child(tb)
    beacon = MeshInstance3D.new()
    var bc := CylinderMesh.new()
    bc.top_radius = 5.0
    bc.bottom_radius = 5.0
    bc.height = 30.0
    beacon.mesh = bc
    var bmat := StandardMaterial3D.new()
    bmat.albedo_color = Color(1, 0.9, 0.2, 0.35)
    bmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    bmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    beacon.material_override = bmat
    world.add_child(beacon)

# ---------- машина ----------
func _spawn_car() -> void:
    if car:
        car.queue_free()
    car = Car.new()
    add_child(car)
    car.setup(car_idx, tune, mode)
    if in_menu:
        car.freeze = true
        car.global_transform = Transform3D(Basis.IDENTITY, Vector3(0, 0.9, 0))
    else:
        _place_car()

func _place_car() -> void:
    var xf := Transform3D(Basis.IDENTITY, Vector3(0, 1.0, 0))
    if mode == "rally":
        var a := cps[0]
        var d := (cps[1] - a).normalized()
        xf = Transform3D(Basis.looking_at(d, Vector3.UP), a + Vector3(0, 1.0, 0))
    car.global_transform = xf
    car.linear_velocity = Vector3.ZERO
    car.angular_velocity = Vector3.ZERO
    cp = 1
    t_lap = 0.0
    cur = 0.0
    total = 0.0
    idle = 0.0
    cam_dir = -xf.basis.z

func _start() -> void:
    in_menu = false
    menu.hide()
    play.show()
    hud.show()
    car.freeze = false
    _place_car()

func _to_menu() -> void:
    in_menu = true
    menu.show()
    play.hide()
    touches.clear()
    car.freeze = true
    car.global_transform = Transform3D(Basis.IDENTITY, Vector3(0, 0.9, 0))

# ---------- управление ----------
func _hit(p: Vector2) -> String:
    for k in rects:
        if rects[k].has_point(p):
            return k
    return ""

func _input(e: InputEvent) -> void:
    if in_menu:
        return
    if e is InputEventScreenTouch:
        if e.pressed:
            var a := _hit(e.position)
            if a != "":
                touches[e.index] = a
        else:
            touches.erase(e.index)
    elif e is InputEventScreenDrag:
        var a2 := _hit(e.position)
        if a2 != "":
            touches[e.index] = a2
        else:
            touches.erase(e.index)

func _drive(dt: float) -> void:
    var acts := touches.values()
    var l := "l" in acts or Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A)
    var r := "r" in acts or Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D)
    var g := "g" in acts or Input.is_key_pressed(KEY_UP) or Input.is_key_pressed(KEY_W)
    var b := "b" in acts or Input.is_key_pressed(KEY_DOWN) or Input.is_key_pressed(KEY_S)
    car.steer_in = float(r) - float(l)
    car.gas = 1.0 if g else 0.0
    car.brk = 1.0 if b else 0.0
    car.hand = "h" in acts or Input.is_key_pressed(KEY_SPACE)
    var kmh := int(car.speed_kmh())
    if mode == "drift":
        var spd := car.linear_velocity.length()
        var ang := car.slip_angle()
        if spd > 6.0 and ang > 0.25:
            cur += spd * ang * dt * 8.0
            idle = 0.0
        else:
            idle += dt
            if idle > 0.8 and cur > 0.0:
                total += cur
                cur = 0.0
        hud.text = "%d км/ч\nОчки: %d  Серия: %d" % [kmh, int(total), int(cur)]
    else:
        t_lap += dt
        var n := cps[cp]
        beacon.global_position = n + Vector3(0, 15, 0)
        if Vector2(car.global_position.x - n.x, car.global_position.z - n.z).length() < 10.0:
            if cp == 0:
                lap_last = t_lap
                best = lap_last if best == 0.0 else minf(best, lap_last)
                t_lap = 0.0
            cp = (cp + 1) % cps.size()
        hud.text = "%d км/ч\nКП %d/%d  %.1f с\nКруг %.1f  Рекорд %.1f" % [kmh, cp, cps.size(), t_lap, lap_last, best]

func _process(dt: float) -> void:
    if in_menu:
        orbit += dt * 0.4
        cam.global_position = Vector3(sin(orbit) * 7.0, 2.6, cos(orbit) * 7.0)
        cam.look_at(Vector3(0, 0.6, 0))
        return
    var fwd := -car.global_transform.basis.z
    fwd.y = 0
    fwd = fwd.normalized()
    cam_dir = cam_dir.lerp(fwd, clampf(dt * 3.0, 0.0, 1.0)).normalized()
    var target := car.global_position - cam_dir * 7.5 + Vector3(0, 3.2, 0)
    cam.global_position = cam.global_position.lerp(target, clampf(dt * 8.0, 0.0, 1.0))
    cam.look_at(car.global_position + cam_dir * 3.0 + Vector3(0, 1, 0))

func _physics_process(dt: float) -> void:
    frame += 1
    if not in_menu:
        _drive(dt)
    if multiplayer.get_peers().size() > 0 and frame % 3 == 0:
        remote_state.rpc(car.global_position, car.global_rotation, car_idx, tune)

# ---------- сеть по локальной сети (ENet) ----------
@rpc("any_peer", "unreliable")
func remote_state(p: Vector3, r: Vector3, idx: int, t: Dictionary) -> void:
    var id := multiplayer.get_remote_sender_id()
    var rc: Car = remotes.get(id)
    var sig := str(idx) + str(t)
    if rc == null or rc.get_meta("sig") != sig:
        if rc:
            rc.queue_free()
        rc = Car.new()
        rc.is_local = false
        add_child(rc)
        rc.setup(idx, t, mode)
        rc.set_meta("sig", sig)
        remotes[id] = rc
    rc.global_position = rc.global_position.lerp(p, 0.5)
    rc.global_rotation = r

func _on_peer_gone(id: int) -> void:
    if remotes.has(id):
        remotes[id].queue_free()
        remotes.erase(id)

func local_ip() -> String:
    for a in IP.get_local_addresses():
        if a.begins_with("192.168.") or a.begins_with("10.") or a.begins_with("172."):
            return a
    return "?"

func _host() -> void:
    var p := ENetMultiplayerPeer.new()
    p.create_server(PORT, 4)
    multiplayer.multiplayer_peer = p
    ip_label.text = "Ты хост. Скажи друзьям IP: " + local_ip()

func _join(ip: String) -> void:
    var p := ENetMultiplayerPeer.new()
    p.create_client(ip.strip_edges(), PORT)
    multiplayer.multiplayer_peer = p
    ip_label.text = "Подключаюсь к " + ip.strip_edges() + " ..."

# ---------- интерфейс ----------
func _layout() -> void:
    var sz := get_viewport().get_visible_rect().size
    rects = {
        "l": Rect2(30, sz.y - 150, 120, 120),
        "r": Rect2(170, sz.y - 150, 120, 120),
        "b": Rect2(sz.x - 450, sz.y - 140, 110, 110),
        "h": Rect2(sz.x - 325, sz.y - 140, 110, 110),
        "g": Rect2(sz.x - 190, sz.y - 190, 160, 160),
    }
    for k in pad_nodes:
        pad_nodes[k].position = rects[k].position
        pad_nodes[k].size = rects[k].size

func _lbl(vb: Control, t: String) -> void:
    var l := Label.new()
    l.text = t
    l.add_theme_font_size_override("font_size", 26)
    vb.add_child(l)

func _opt(vb: Control, title: String, items: Array, sel: int, cb: Callable) -> OptionButton:
    _lbl(vb, title)
    var o := OptionButton.new()
    for i in items.size():
        o.add_item(items[i], i)
    o.selected = sel
    o.custom_minimum_size.y = 64
    o.add_theme_font_size_override("font_size", 26)
    o.get_popup().add_theme_font_size_override("font_size", 30)
    o.item_selected.connect(cb)
    vb.add_child(o)
    return o

func _sld(vb: Control, title: String, key: String, mn: float, mx: float) -> HSlider:
    _lbl(vb, title)
    var s := HSlider.new()
    s.min_value = mn
    s.max_value = mx
    s.step = 0.05
    s.value = tune[key]
    s.custom_minimum_size.y = 48
    vb.add_child(s)
    return s

func _col(vb: Control, title: String, key: String) -> ColorPickerButton:
    _lbl(vb, title)
    var c := ColorPickerButton.new()
    c.color = tune[key]
    c.custom_minimum_size.y = 56
    c.color_changed.connect(_on_col.bind(key))
    vb.add_child(c)
    return c

func _btn(vb: Control, t: String, cb: Callable) -> Button:
    var b := Button.new()
    b.text = t
    b.custom_minimum_size.y = 70
    b.add_theme_font_size_override("font_size", 28)
    b.pressed.connect(cb)
    vb.add_child(b)
    return b

func _on_col(c: Color, key: String) -> void:
    tune[key] = c
    car.apply_paint()

func _on_phys(v: float, key: String) -> void:
    tune[key] = v
    car.apply_physics()

func _on_rim_end(_changed: bool) -> void:
    tune["rim_size"] = rim_slider.value
    _spawn_car()

func _on_car(i: int) -> void:
    car_idx = i
    tune["color"] = Data.CARS[i].color
    body_picker.color = tune["color"]
    _spawn_car()

func _on_mode(i: int) -> void:
    mode = ["drift", "rally"][i]
    _build_world()
    _spawn_car()

func _on_engine(i: int) -> void:
    tune["engine"] = i
    car.apply_physics()

func _on_kit(i: int) -> void:
    tune["kit"] = i
    _spawn_car()

func _on_wing(i: int) -> void:
    tune["wing"] = i
    _spawn_car()

func _build_ui() -> void:
    var ui := CanvasLayer.new()
    add_child(ui)
    # игровой экран
    play = Control.new()
    play.set_anchors_preset(Control.PRESET_FULL_RECT)
    play.mouse_filter = Control.MOUSE_FILTER_IGNORE
    play.hide()
    ui.add_child(play)
    hud = Label.new()
    hud.position = Vector2(24, 16)
    hud.add_theme_font_size_override("font_size", 30)
    hud.add_theme_color_override("font_outline_color", Color.BLACK)
    hud.add_theme_constant_override("outline_size", 8)
    play.add_child(hud)
    var mb := Button.new()
    mb.text = "☰"
    mb.add_theme_font_size_override("font_size", 34)
    mb.anchor_left = 1.0
    mb.anchor_right = 1.0
    mb.offset_left = -100
    mb.offset_right = -20
    mb.offset_top = 20
    mb.offset_bottom = 100
    mb.pressed.connect(_to_menu)
    play.add_child(mb)
    var labels := {"l": "◀", "r": "▶", "b": "Тормоз", "h": "Ручник", "g": "ГАЗ"}
    for k in labels:
        var cr := ColorRect.new()
        cr.color = Color(1, 1, 1, 0.3) if k != "g" else Color(1, 0.35, 0.2, 0.5)
        cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
        var lb := Label.new()
        lb.text = labels[k]
        lb.set_anchors_preset(Control.PRESET_FULL_RECT)
        lb.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        lb.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        lb.add_theme_font_size_override("font_size", 28)
        lb.mouse_filter = Control.MOUSE_FILTER_IGNORE
        cr.add_child(lb)
        play.add_child(cr)
        pad_nodes[k] = cr
    # гараж
    menu = PanelContainer.new()
    menu.anchor_left = 0.5
    menu.anchor_right = 1.0
    menu.anchor_top = 0.0
    menu.anchor_bottom = 1.0
    ui.add_child(menu)
    var sc := ScrollContainer.new()
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    menu.add_child(sc)
    var vb := VBoxContainer.new()
    vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    vb.add_theme_constant_override("separation", 8)
    sc.add_child(vb)
    _opt(vb, "Машина", Data.CARS.map(func(c): return c.n), car_idx, _on_car)
    _opt(vb, "Режим", ["Дрифт", "Ралли"], 0, _on_mode)
    _opt(vb, "Свап мотора", Data.ENGINES.map(func(e): return e.n), 0, _on_engine)
    _lbl(vb, "— Подвеска —")
    _sld(vb, "Жёсткость", "stiff", 0.0, 1.0).value_changed.connect(_on_phys.bind("stiff"))
    _sld(vb, "Клиренс (выше для ралли)", "height", 0.0, 1.0).value_changed.connect(_on_phys.bind("height"))
    _sld(vb, "Баланс сцепления (перед ← → зад)", "bias", 0.0, 1.0).value_changed.connect(_on_phys.bind("bias"))
    _lbl(vb, "— Кастомизация —")
    body_picker = _col(vb, "Цвет кузова", "color")
    _opt(vb, "Обвес", ["Сток", "Спорт", "Широкий"], 0, _on_kit)
    _opt(vb, "Спойлер", ["Нет", "Дакктейл", "GT-крыло"], 0, _on_wing)
    _col(vb, "Цвет дисков", "rim")
    rim_slider = _sld(vb, "Размер дисков", "rim_size", 0.8, 1.3)
    rim_slider.drag_ended.connect(_on_rim_end)
    _lbl(vb, "— Сеть (Wi-Fi) —")
    _btn(vb, "Создать комнату", _host)
    var le := LineEdit.new()
    le.placeholder_text = "IP хоста, например 192.168.0.12"
    le.custom_minimum_size.y = 64
    le.add_theme_font_size_override("font_size", 26)
    vb.add_child(le)
    _btn(vb, "Подключиться", func(): _join(le.text))
    ip_label = Label.new()
    ip_label.add_theme_font_size_override("font_size", 22)
    ip_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(ip_label)
    _btn(vb, "ЕХАТЬ", _start)
    var cr2 := Label.new()
    cr2.text = "Модель Lancer Evo VII: Nieve5677 (Sketchfab), CC BY 4.0"
    cr2.add_theme_font_size_override("font_size", 16)
    cr2.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    vb.add_child(cr2)
