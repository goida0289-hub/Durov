# JDM Drift Rally (Godot 4.3+)

Мобильная 3D-игра: дрифт и ралли, 8 машин, свапы моторов, подвеска, кастомизация, игра по Wi-Fi.
Проект не тестировался на устройстве. Возможно, придётся подкрутить числа (см. «Настройка»).

## 1. Подготовь модель Lancer Evo VII
1. Sketchfab: https://skfb.ly/pvJUO -> Download 3D Model -> формат glTF (нужен аккаунт). Лицензия CC BY 4.0: автора нужно указать (в игре уже есть строка в меню).
2. Модель весит 1,1 млн полигонов, для телефона это слишком много. Открой в Blender (бесплатно), добавь модификатор Decimate (Collapse, Ratio около 0.04, это ~45 тыс. полигонов), экспортируй как .glb.
3. Положи файл в `models/lancer_evo7.glb`. Без файла игра запустится с простой заглушкой-кузовом.
4. Остальные машины так же: найди модель с разрешающей лицензией, прореди, положи в `models/` и поправь имя файла в `scripts/data.gd`.

## 2. Запуск и сборка APK
1. Скачай Godot 4.3+ (обычная версия, не .NET). Открой папку проекта.
2. Editor -> Manage Export Templates -> Download and Install.
3. Поставь JDK 17 и Android SDK (проще всего через Android Studio: platform-tools, build-tools 34, platform 34, cmdline-tools).
4. Editor -> Editor Settings -> Export -> Android: укажи пути к Java SDK и Android SDK.
5. Создай debug-ключ командой:
   keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore debug.keystore -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999 -deststoretype pkcs12
   и укажи его в Editor Settings -> Export -> Android -> Debug Keystore (пользователь androiddebugkey, пароль android).
6. Project -> Export -> Add... -> Android. Включи разрешения Internet и Access Network State (нужны для сети).
7. Export Project -> сохрани как .apk. Скинь на телефон и установи (разреши установку из неизвестных источников).

## 3. Настройка под твои модели
- `scripts/data.gd`: `scale`, `yaw` (поворот), `dy` (высота) для каждой машины; `paint` это кусок названия материала кузова (смотри в Godot: двойной клик на .glb -> Materials).
- Если машина едет задом: поверни модель через `yaw = 3.14159`.
- `POWER_K` в `data.gd`: общая мощность. Если машина еле едет или улетает, меняй число.
- Колёса модели прячутся по названию узлов (`HIDE` в `data.gd`), вместо них свои колёса с кастомными дисками.
- Обвесы и спойлеры это простые детали, позиции в `car.gd` (`_add_kit`) подгоняются под кузов.

## 4. Игра по локальной сети
Все на одном Wi-Fi. Один нажимает «Создать комнату» и называет остальным показанный IP, остальные вводят его и жмут «Подключиться». Порт 9999.

## Управление
Экран: ◀ ▶, газ, тормоз, ручник. Компьютер: стрелки/WASD, пробел это ручник.
